const baseUrl = 'https://swapi.dev/api/';

export default class SwapiHelper {
    // expects an id for the outpyut emement, the element where we want the lisst of films displayed, 
    // and an element thatwill show during the initial load. 
    constructor(outputId, filmId, loadingId) {
        this.outputId = outputId;
        this.outputElement = document.getElementById(outputId);
        this.filmId = filmId;
        this.filmElement = document.getElementById(filmId);
        this.loadingId = loadingId;
        this.loadingElement = document.getElementById(loadingId);
        this.films = [];
        this.init();
    }
    async init() {
        //the api is sometimes slow... lets gice the users something to look at while they wait...
        this.outputElement.style.display = "none";
        this.loadingElement.style.display = "block";
        this.films = await this.makeRequest(baseUrl + "films");
        this.films = this.films.results;
        console.log(this.films);
        // Once we have our film data remove loading indicator.
        /*Phase 2*/
        this.outputElement.style.display = "initial";
        this.loadingElement.style.display = "none";
        this.clickableList(this.films, this.filmId, this.filmSelected.bind(this));

    }
    async makeRequest(url) {
        try {
            const response = await fetch(url);
            if (response.ok) {
                return await response.json();
            } else {
                const error = await response.text();
                throw new Error(error);
            }
        } catch (err) {
            console.log(err);
        }
    }
    /*Phase 2*/
    clickableList(list, elementId, callback) {
        const element = document.getElementById(elementId);
        element.innerHTML = list.map((film) => `<li>${film.title}</li>`).join("");
        element.addEventListener("click", (e) => {
            console.log(e.target);

            callback(e.target.innerText);
        });
    }

    async filmSelected(filmTitle) {
        try {
            const film = this.films.find((item) => item.title === filmTitle);
            if (!film) {
                throw new Error("Film not found");
            }
            // setup the intital html structure for the film
            this.outputElement.innerHTML = this.pageTemplate();
            // set film title and other info
            this.outputElement.querySelector(".film-name").innerText = film.title;
            this.outputElement.querySelector(".crawl").innerText = film.opening_crawl;
        
        } catch (err) {
            console.log(err);
        }
    }
    pageTemplate(filmTitle) {
        return `<h2 class="film-name"></h2>
            <p class="crawl"></p>
            <section class="planets">
                <h3>Planets</h3>
                <ul class="detail-list film-planets"></ul>
            </section>
            <section class="ships">
                <h3>Starships</h3>
                <ul class="detail-list film-starships"></ul>
            </section>`;
    }
}