import SwapiHelper from "./SwapiHelper.js";

const myHelper = new SwapiHelper("output", "films", "loading");

// myHelper.init();

